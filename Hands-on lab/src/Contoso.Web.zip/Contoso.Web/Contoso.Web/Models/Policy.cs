﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Contoso.Web.Models
{
    public class Policy
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        [DisplayFormat(DataFormatString = "{0:C2}")]
        public decimal DefaultDeductible { get; set; }
        [DisplayFormat(DataFormatString = "{0:C2}")]
        public decimal DefaultOutOfPocketMax { get; set; }
    }
}