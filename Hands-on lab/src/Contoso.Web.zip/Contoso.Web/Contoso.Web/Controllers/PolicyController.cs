﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;

using Contoso.Web.Models;

namespace Contoso.Web.Controllers
{
    public class PolicyController : Controller
    {
        private readonly string connectionString = ConfigurationManager.AppSettings["SqlConnectionString"];
        // GET: Policy
        public ActionResult Index()
        {
            List<Policy> policies = new List<Policy>();

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "SELECT * FROM policies";
                command.CommandType = CommandType.Text;

                conn.Open();

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    var policy = new Policy
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        Description = reader.GetString(2),
                        DefaultDeductible = reader.GetDecimal(3),
                        DefaultOutOfPocketMax = reader.GetDecimal(4)
                    };

                    policies.Add(policy);
                }
            }

            ViewBag.Policies = policies;
            return View();
        }

        [HttpGet]
        public ActionResult GetPolicy(string Id)
        {
            Policy policy = new Policy();

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand())
            {
                SqlParameter param = command.CreateParameter();
                param.ParameterName = "@Id";
                param.SqlDbType = SqlDbType.Int;
                param.Value = Id;

                command.Connection = conn;
                command.CommandText = "SELECT * FROM policies WHERE Id = @Id";
                command.CommandType = CommandType.Text;
                command.Parameters.Add(param);

                conn.Open();

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    policy.Id = reader.GetInt32(0);
                    policy.Name = reader.GetString(1);
                    policy.Description = reader.GetString(2);
                    policy.DefaultDeductible = reader.GetDecimal(3);
                    policy.DefaultOutOfPocketMax = reader.GetDecimal(4);
                }
            }

            return View(policy);
        }
    }
}