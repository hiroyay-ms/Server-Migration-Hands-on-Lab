﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;

using Contoso.Web.Models;

namespace Contoso.Web.Controllers
{
    public class PeopleController : Controller
    {
        private readonly string connectionString = ConfigurationManager.AppSettings["SqlConnectionString"];
        // GET: People
        public ActionResult Index()
        {
            List<Person> people = new List<Person>();

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "SELECT * FROM people";
                command.CommandType = CommandType.Text;

                conn.Open();

                SqlDataReader reader = command.ExecuteReader();

                while(reader.Read())
                {
                    var person = new Person
                    {
                        Id　= reader.GetInt32(0),
                        FName = reader.GetString(1),
                        LName = reader.GetString(2),
                        Dob = reader.GetDateTime(3),
                        Address = reader.GetString(4),
                        Address2 = reader.GetString(5),
                        City = reader.GetString(6),
                        Suburb = reader.GetString(7),
                        Postcode = reader.GetString(8)
                    };

                    people.Add(person);
                }
            }

            ViewBag.People = people;
            return View();
        }

        [HttpGet]
        public ActionResult GetPerson(string Id)
        {
            Person person = new Person();

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "SELECT * FROM people WHERE Id = " + Id;
                command.CommandType = CommandType.Text;

                conn.Open();

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    person.Id = reader.GetInt32(0);
                    person.FName = reader.GetString(1);
                    person.LName = reader.GetString(2);
                    person.Dob = reader.GetDateTime(3);
                    person.Address = reader.GetString(4);
                    person.Address2 = reader.GetString(5);
                    person.City = reader.GetString(6);
                    person.Suburb = reader.GetString(7);
                    person.Postcode = reader.GetString(8);
                }
            }

            return View(person);
        }
    }
}